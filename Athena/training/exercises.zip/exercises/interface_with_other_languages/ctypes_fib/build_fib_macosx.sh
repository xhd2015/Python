gcc -dynamiclib -arch i386 fib.c -o libfib.so
