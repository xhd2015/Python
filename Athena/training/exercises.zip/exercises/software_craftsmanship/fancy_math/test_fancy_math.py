from numpy import Inf
from nose.tools import assert_almost_equal, assert_equal

from fancy_math import slope

def test_slope_xxx():
    pass