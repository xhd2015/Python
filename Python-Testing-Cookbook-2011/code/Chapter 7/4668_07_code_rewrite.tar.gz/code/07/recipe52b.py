from network import *
import unittest
from springpython.database.factory import *
from springpython.database.core import *

class EventCorrelationTest(unittest.TestCase):
    def setUp(self):
        db_name = "recipe52b.db"
        factory = Sqlite3ConnectionFactory(db=db_name)
        self.correlator = EventCorrelator(factory)

        dt = DatabaseTemplate(factory)
        sql = open("network.sql").read().split(";")
        for statement in sql:
            dt.execute(statement + ";")

    def test_process_events(self):
        evt1 = Event("pyhost1", "serverRestart", 5)
        evt2 = Event("pyhost2", "lineStatus", 5)
        evt3 = Event("pyhost2", "lineStatus", 1)
        evt4 = Event("pyhost1", "serverRestart", 1)

        for event in [evt1, evt2, evt3, evt4]:
            stored_event, is_active, \
               updated_services, updated_equipment = \
                         self.correlator.process(event)

            print "Stored event: %s" % stored_event
            if is_active:
                print "This event was an active event."

            print "Updated services: %s" % updated_services
            print "Updated equipment: %s" % updated_equipment
            print "---------------------------------"

if __name__ == "__main__":
    unittest.main()
        
