from network import *
import unittest
from springpython.database.factory import *
from springpython.database.core import *

class EventCorrelationTest(unittest.TestCase):
    def setUp(self):
        db_name = "recipe55.db"
        factory = Sqlite3ConnectionFactory(db=db_name)
        self.correlator = EventCorrelator(factory)

        dt = DatabaseTemplate(factory)
        sql = open("network.sql").read().split(";")
        for statement in sql:
            dt.execute(statement + ";")

    def test_process_events(self):
        evt1 = Event("pyhost1", "serverRestart", 5)

        stored_event, is_active, \
           updated_services, updated_equipment = \
                     self.correlator.process(evt1)

        print "Stored event: %s" % stored_event
        if is_active:
            print "This event was an active event."

        print "Updated services: %s" % updated_services
        print "Updated equipment: %s" % updated_equipment
        print "---------------------------------"

