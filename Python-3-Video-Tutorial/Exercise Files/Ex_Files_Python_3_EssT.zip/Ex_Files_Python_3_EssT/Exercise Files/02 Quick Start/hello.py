#!/usr/bin/python3

print("Hello, World!")
